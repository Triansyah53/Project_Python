

from robot.api import logger



def first_method_in_custom():
    """

    Returns:

    """

    logger.console("FIRST CUSTOM METHOD IN MODULE")


def second_method_in_custom():
    """

    Returns:

    """

    logger.console("SECOND CUSTOM METHOD IN MODULE")