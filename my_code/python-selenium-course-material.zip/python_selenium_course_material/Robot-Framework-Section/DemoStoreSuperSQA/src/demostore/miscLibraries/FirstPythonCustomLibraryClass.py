
from robot.api import logger


class FirstPythonCustomLibraryClass(object):

    def first_keyword_in_class(self):
        logger.console("FIRST METHOD IN CLASS")

    def second_keyword_in_class(self):
        logger.console("SECOND METHOD IN CLASS")