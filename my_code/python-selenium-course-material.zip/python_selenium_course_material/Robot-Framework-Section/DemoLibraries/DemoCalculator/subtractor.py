


def sub(x,y):
    print("I am subtracking {} from {}".format(y,x))
    return x - y