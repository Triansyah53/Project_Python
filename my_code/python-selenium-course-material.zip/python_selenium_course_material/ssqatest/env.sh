

export BROWSER=chrome

export RESULTS_DIR=./results

export DB_USER=root
export DB_PASSWORD=<your password here> if you areusing MAMP password is root

export API_KEY=<your key here>
export API_SECRET=<your secret here>
