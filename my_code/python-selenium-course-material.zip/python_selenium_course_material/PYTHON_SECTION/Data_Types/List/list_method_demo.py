

countries = ["USA", "Mexico", 'Canada', 'India', 'Germany', 'Japan']
print(countries)
# print(type(countries))
# no_of_countries = len(countries)
# print(no_of_countries)

# adding element to list
# countries.append('China')
# print(countries)
# print(len(countries))

# removing element from list
# countries.remove('Canada')
# print(countries)

# another way to remove (only the last element)
my_c = countries.pop()
print(countries)
print(my_c)

abc = {'ad': 123}