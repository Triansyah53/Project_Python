

# full_name = 'Admas Kinfu'
# name_s = full_name.split()
# print(full_name)
# print(name_s)

# ssn = "111-22-3333"
# ssn_s = ssn.split('-')
# print(ssn)
# print(ssn_s)

full_name = 'Admas Kinfu.'
# print(full_name)
# name_clean = full_name.strip('.')
# print(name_clean)

# print(full_name.upper())
# print(full_name.lower())

# url = 'https://supersqa.com/'
# is_home = url.endswith('.com/shop')
# is_absolute = url.startswith('https')
# print(is_home)
# print(is_absolute)

info = "This%20is%20url%20encoded."
info2 = info.replace("%20", " ")
print(info)
print(info2)