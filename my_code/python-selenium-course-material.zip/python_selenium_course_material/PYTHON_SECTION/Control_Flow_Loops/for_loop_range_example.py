

# for i in range(5):
#     print(i)
#
# for i in range(2, 5):
#     print(i)
#
my_list = []
for i in range(10):
    my_list.append('abc')
print(my_list)
print(len(my_list))